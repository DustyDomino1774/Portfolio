/*
//Project Name: CS20 Project Binary Search Functions
//
//Project Description: The Description says it all
//
//Project Author: London, Dominic
//
//Is this an extra credit Project: No
//
//Date completed: 04/21/2018
//
//Operating system used: Windows
//
//IDE Used:  Eclipse
 * P.S. this project nearly broke me.
 */

int BinaryTree::calculateBalance(TreeNode* rootNode) {

	if (rootNode == nullptr)
	{
		return 0;
	}

	else if ((rootNode->Left == nullptr) && (rootNode->Right == nullptr))
	{
		return 1;
	}

	else
	{
		int left = calculateBalance(rootNode->Left) +1;
		int right = calculateBalance(rootNode->Right) +1;
		rootNode->BalanceFactor = (left - right);
		return 1 + max(calculateBalance(rootNode->Left),calculateBalance(rootNode->Right));
	}

}//calculateBalance

//
//Private function returning the balance factor of a particular node.  Called by isInBalance
int BinaryTree::calculateHeight(TreeNode* rootNode) {

	if (rootNode == nullptr)
	{
		return 0;
	}

	else if ((rootNode->Left == nullptr) && (rootNode->Right == nullptr))
	{
		return 0;
	}

	else
	{
		return 1 + max(calculateHeight(rootNode->Left),calculateHeight(rootNode->Right));
	}

}//calculateHeight

//
//Private function which returns the largest balance factor in the entire tree.  Called by largestBF
int BinaryTree::getLargestBF(TreeNode* rootNode) {

	if (rootNode == nullptr)
	{
		return 0;
	}

	else if ((rootNode->Left == nullptr) && (rootNode->Right == nullptr))
	{
		return rootNode->BalanceFactor;
	}

	else
	{
		int leftBF = abs(getLargestBF(rootNode->Left));
		int rightBF = abs(getLargestBF(rootNode->Right));
		if (leftBF > rightBF)
		{
			return max(abs(rootNode->BalanceFactor),leftBF);
		}
		else if (rightBF > leftBF)
		{
			return max(abs(rootNode->BalanceFactor),rightBF);
		}
		else
		{
			return abs(rootNode->BalanceFactor);
		}
	}

	//	if (rootNode == nullptr)
	//		{
	//			return 0;
	//		}
	//
	//		else if ((rootNode->Left == nullptr) && (rootNode->Right == nullptr))
	//		{
	//			return 0;
	//		}
	//
	//		else
	//		{
	//			return 1 + max(calculateHeight(rootNode->Left),calculateHeight(rootNode->Right));
	//		}

	//	int LBF = rootNode->BalanceFactor;
	//
	//	if (rootNode == nullptr)
	//	{
	//		LBF = 0;
	//		return LBF;
	//	}
	//
	//	else if ((rootNode->Left == nullptr) && (rootNode->Right == nullptr))
	//	{
	//		LBF = rootNode->BalanceFactor;
	//		return LBF;
	//	}
	//
	//	else
	//	{
	//		int largestLeft = abs(getLargestBF(rootNode->Left));
	//		int largestRight = getLargestBF(rootNode->Right);
	//
	//		if(largestLeft > LBF)
	//		{
	//			if (largestRight > largestLeft)
	//			{
	//				return largestRight;
	//			}
	//
	//			else
	//			{
	//				return largestLeft;
	//			}
	//		}
	//
	//		if(largestRight > LBF)
	//		{
	//
	//			return largestRight;
	//		}
	//		else
	//		{
	//			return LBF;
	//		}
	//	}

	//You need to do this

}//getLargestBF



